package com.jarvis.app

import android.accessibilityservice.AccessibilityService
import android.service.notification.NotificationListenerService
import android.view.accessibility.AccessibilityEvent

class JarvisAccessibility : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}
}

class JarvisListener : NotificationListenerService()
