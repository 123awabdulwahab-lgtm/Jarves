package com.jarvis.app

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient

class Bridge(private val a: Activity) {
    private fun granted(p: String) =
        a.checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    private fun enabledIn(key: String) =
        (Settings.Secure.getString(a.contentResolver, key) ?: "").contains(a.packageName)

    @JavascriptInterface
    fun status(): String {
        val notif = if (Build.VERSION.SDK_INT >= 33)
            granted("android.permission.POST_NOTIFICATIONS") else true
        val pm = a.getSystemService(Context.POWER_SERVICE) as PowerManager
        return "{" +
            "\"mic\":" + granted(Manifest.permission.RECORD_AUDIO) + "," +
            "\"notif\":" + notif + "," +
            "\"access\":" + enabledIn("enabled_accessibility_services") + "," +
            "\"listener\":" + enabledIn("enabled_notification_listeners") + "," +
            "\"overlay\":" + Settings.canDrawOverlays(a) + "," +
            "\"battery\":" + pm.isIgnoringBatteryOptimizations(a.packageName) +
            "}"
    }

    @JavascriptInterface
    fun open(what: String) {
        a.runOnUiThread {
            val pkg = Uri.parse("package:" + a.packageName)
            try {
                when (what) {
                    "mic" -> a.requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
                    "notif" -> if (Build.VERSION.SDK_INT >= 33)
                        a.requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 2)
                    "access" -> a.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                    "listener" -> a.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                    "overlay" -> a.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, pkg))
                    "battery" -> a.startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, pkg))
                    "appinfo" -> a.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, pkg))
                }
            } catch (e: Exception) {
                a.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, pkg))
            }
        }
    }
}

class MainActivity : Activity() {
    private lateinit var web: WebView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.webViewClient = WebViewClient()
        web.addJavascriptInterface(Bridge(this), "Android")
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
    }

    override fun onResume() {
        super.onResume()
        web.evaluateJavascript("window.refresh && refresh()", null)
    }

    override fun onRequestPermissionsResult(code: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(code, p, r)
        web.evaluateJavascript("window.refresh && refresh()", null)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        web.evaluateJavascript("window.goBack ? window.goBack() : false") { r ->
            if (r != "true") super.onBackPressed()
        }
    }
}
